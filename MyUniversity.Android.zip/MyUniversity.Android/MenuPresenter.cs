using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using MyUniversity.Core.AuthenticationModel;
using MyUniversity.Core.ProfileModel;
using MyUniversity.Core.NotificationModel;
using MyUniversity.Core.�ommonCode;
using MyUniversity.Core.RatingModel;
using MyUniversity.Core.ScheduleModel;
using MyUniversity.Core.Model;
using System.Threading.Tasks;

namespace MyUniversity.Android
{
    public class MenuPresenter
    {
        public readonly IViewMainPage _view;

        public readonly IMainModel _model;


        public MenuPresenter(IViewMainPage view, IMainModel model)
        {
            _view = view;
            _model = model;

            _model.NoNetwork += _model_NoNetwork;
            _model.IncorrectAuthData += _model_IncorrectAuthData;
            _model.AccessToSiteProblem += _model_AccessToSiteProblem;
        }

        private void _model_AccessToSiteProblem(object sender, Core.�ommon_Code.MessageEvent e)
        {
            _view.ViewMessage(e.Message);
        }

        private void _model_IncorrectAuthData(object sender, Core.�ommon_Code.MessageEvent e)
        {
            _view.ViewMessage("��������� ��������� �����������. ��������� ������� ��������� ������");
        }

        private void _model_NoNetwork(object sender, Core.�ommon_Code.MessageEvent e)
        {
            _view.ViewMessage(e.Message);
        }




        public async Task<StydentProfile> GetProfile()
        {
            return new StydentProfile(await _model.GetProfile());
        }


        public async Task<List<Core.NotificationModel.Notification>> GetNotification()
        {
            return await _model.GetNotifications();
        }

        public async Task<List<Lesson>> GetLessons()
        {
            return await _model.GetLessons();
        }


        public async Task<Tuple<List<WeekData>, List<ScheduleItem>>> GetSchedulse()
        {
            return await _model.GetAllSchedules();
        }


    }
}