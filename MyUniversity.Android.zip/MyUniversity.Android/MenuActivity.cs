using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;

using MyUniversity.Core.AuthenticationModel;
using Newtonsoft.Json;

using Android.Support.V7.App;
using Android.Support.V4.Widget;
using Android.Support.Design.Widget;
using Android.Support.V7.Widget;
using Android.Graphics;
using Android.Views;
using Android.Widget;
using MyUniversity.Core.ProfileModel;
using MyUniversity.Core.NotificationModel;
using MyUniversity.Core.RatingModel;
using MyUniversity.Core.ScheduleModel;
using MyUniversity.Core.Model;

using SupportFragment = Android.Support.V4.App.Fragment;

namespace MyUniversity.Android
{
    public interface IViewMainPage
    {
        void ViewMenuHeaderInformation(string text);
        void ViewMessage(string text);
    }

    [Activity(Label = "MenuActivity")]
    public class MenuActivity : AppCompatActivity, IViewMainPage
    {
       public MenuPresenter _presenter;

        StydentProfile _prof;
      

        DrawerLayout drawerLayout;
        TextView txtV_email;
        ImageView imgV_profile;




        SupportFragment currentfragment;

        InformationFragment infofragment;
        ProfileFragment proffragment;
        MessagesFragment messfragment;
        LessonsFragment lessfragment;
        ScheduleFragment schedfragment;

        protected async override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here




            Tuple<StorageAccount, StorageAccount, StorageAccount, StorageAccount> _authdata = 
                JsonConvert.DeserializeObject<Tuple<StorageAccount, StorageAccount, StorageAccount, StorageAccount>>(Intent.GetStringExtra("authdata"));

            _presenter = new MenuPresenter(this, new MainModel(MainActivity.platform, MainActivity.documentsPath, new StorageServise(), _authdata));



            _prof = await _presenter.GetProfile();
           
           

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);


            drawerLayout = FindViewById<DrawerLayout>(Resource.Id.drawer_layout);

            // Init toolbar          
            var toolbar = FindViewById<Toolbar>(Resource.Id.app_bar);
            SetSupportActionBar(toolbar);

            SupportActionBar.SetTitle(Resource.String.app_name);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);
           
            // Attach item selected handler to navigation view
            //������������  ���������� ���������
            var navigationView = FindViewById<NavigationView>(Resource.Id.nav_view);
            navigationView.NavigationItemSelected += NavigationView_NavigationItemSelected;

         

            // Create ActionBarDrawerToggle button and add it to the toolbar
            //      var drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, Resource.String.open_drawer, Resource.String.close_drawer);
            //   drawerLayout.SetDrawerListener(drawerToggle);
            //     drawerToggle.SyncState();
            var drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, Resource.String.open_drawer, Resource.String.close_drawer);
            drawerLayout.SetDrawerListener(drawerToggle);
            drawerToggle.SyncState();

            //load default home screen
            //����� �������� �� ���������


            //frManager = FragmentManager.BeginTransaction();

            //setfragment = inf;
            //// Replace the fragment that is in the View fragment_container (if applicable).
            //  frManager.Add(Resource.Id.HomeFrameLayout, inf);

            //// Add the transaction to the back stack.
            //   frManager.AddToBackStack(null);

            //// Commit the transaction.
            //    frManager.Commit();

            //frManager.Hide(inf);

            //ViewMenuHeaderInformation(_prof.LastName + " " + _prof.FierstName);


            infofragment = new InformationFragment();
            proffragment = new ProfileFragment();
            messfragment = new MessagesFragment();
            lessfragment=new LessonsFragment();
            schedfragment=new ScheduleFragment();

            currentfragment = infofragment;

            var supf = SupportFragmentManager.BeginTransaction();
            
            supf.Add(Resource.Id.HomeFrameLayout, proffragment, "Prof");
            supf.Hide(proffragment);

            supf.Add(Resource.Id.HomeFrameLayout, messfragment, "Prof");
            supf.Hide(messfragment);


            supf.Add(Resource.Id.HomeFrameLayout, lessfragment, "Less");
            supf.Hide(messfragment);


            supf.Add(Resource.Id.HomeFrameLayout, schedfragment, "Sched");
            supf.Hide(messfragment);

            supf.Add(Resource.Id.HomeFrameLayout, infofragment, "Info");
            supf.Commit();
        }



        private void ShowFragment(SupportFragment currnt)
        {
            var trans = SupportFragmentManager.BeginTransaction();
            if (currnt != currentfragment)
            {
                trans.Show(currnt);
                trans.Hide(currentfragment);
                trans.AddToBackStack(null);
                trans.Commit();

                currentfragment = currnt;
            }
        }

        //define action for navigation menu selection
        //
        private async void NavigationView_NavigationItemSelected(object sender, NavigationView.NavigationItemSelectedEventArgs e)
        {

            switch (e.MenuItem.ItemId)
            {
                case (Resource.Id.nav_profile):
                    ShowFragment(proffragment);
                    ViewProfile(await _presenter.GetProfile());
                    //pf = new ProfileFragment();
                    //frManager.Add(Resource.Id.HomeFrameLayout, pf);
                    //frManager.Commit();
                    //ViewProfile(await _presenter.GetProfile());
                    break;
                case (Resource.Id.nav_messages):
                    ShowFragment(messfragment);
                    ViewMessages(await _presenter.GetNotification());
                    break;
                case (Resource.Id.nav_brs):
                    ShowFragment(lessfragment);
                    ViewRating(await _presenter.GetLessons());
                    //lf = new LessonsFragment();
                    //frManager.Add(Resource.Id.HomeFrameLayout, lf);
                    //frManager.Commit();

                    break;
                case (Resource.Id.nav_schedules):
                    ShowFragment(schedfragment);
                    ViewSchedule(await _presenter.GetSchedulse());
                    //schf = new ScheduleFragment();
                    //frManager.Add(Resource.Id.HomeFrameLayout, schf);
                    //frManager.Commit();
                    //ViewSchedule(await _presenter.GetSchedulse());
                    break;
                case (Resource.Id.nav_information):
                    ShowFragment(infofragment);
                    break;
                default:
                    Snackbar.Make(drawerLayout, "��������! " + "Punctmenunenaiden", Snackbar.LengthLong)
            .SetAction("OK", (v) => { }).Show(); break;
            }
            // Close drawer

            drawerLayout.CloseDrawers();
        }


        //define custom title text
        protected override void OnResume()
        {
            //SupportActionBar.SetTitle(Resource.String.app_name);
            base.OnResume();
        }
        //define action for tolbar icon press
        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.home:
                   // this.Activity.Finish();
                    return true;
              
                default:
                    return base.OnOptionsItemSelected(item);
            }
        }
        //to avoid direct app exit on backpreesed and to show fragment from stack
        public override void OnBackPressed()
        {
            if (FragmentManager.BackStackEntryCount != 0)
                FragmentManager.PopBackStack();// fragmentManager.popBackStack();
            else
                base.OnBackPressed();
        }




        public void ViewMenuHeaderInformation(string text)
        {
            /*
            txtV_email = FindViewById<TextView>(Resource.Id.header_email);
            txtV_email.Text = text;

            imgV_profile = FindViewById<ImageView>(Resource.Id.header_image);
            imgV_profile.SetImageBitmap(BitmapFactory.DecodeFile
               (System.Environment.GetFolderPath
               (System.Environment.SpecialFolder.Personal) + "imageprof.jpg"));
               */
        }

        public void ViewMessage(string text)
        {
            Snackbar.Make(drawerLayout, "��������! " + text, Snackbar.LengthLong)
               .SetAction("OK", (v) => { }).Show();
        }


        private void ViewProfile(StydentProfile prof)
        {
            proffragment.ViewProfile(prof);
        }
        private void ViewMessages(List<Core.NotificationModel.Notification> items)
        {
            messfragment.ViewNotifications(items);
            //vizvar metod frama
            //elsi fragment eshe activen otobrapbnm novii dannii
        }
        private void ViewRating(List<Lesson> items)
        {
          //  lf.ViewLessons(items);
        }
        private void ViewSchedule(Tuple<List<WeekData>, List<ScheduleItem>> items)
        {
         //   schf.ViewSchedule(items);
        }













   
    }
}